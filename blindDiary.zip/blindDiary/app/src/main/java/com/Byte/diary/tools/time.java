package com.Byte.diary.tools;

import java.text.SimpleDateFormat;
import java.util.Date;

public class time {
    public static String getTime() { //获取系统时间
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss"); //重置格式
        Date date = new Date();
        String time = simpleDateFormat.format(date); //获取系统时间
        return time;
    }
}
